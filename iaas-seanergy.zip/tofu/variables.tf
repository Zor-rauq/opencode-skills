variable "grappe_numero" {
  description = "Numero de la grappe a deployer. Doit exister dans grappes.yaml."
  type        = number

  validation {
    condition     = var.grappe_numero >= 1 && var.grappe_numero <= 25
    error_message = "Le numero de grappe doit etre compris entre 1 et 25 (numero*10+3 <= 254)."
  }
}

variable "fichier_grappes" {
  description = "Chemin du fichier declaratif. Ne pas changer sans raison."
  type        = string
  default     = "../grappes.yaml"
}

# --- Parametres d'infrastructure, fournis par la CI (variables GitLab) --------

variable "network_id" {
  description = "ID du reseau IaaS portant les subnets seanergy."
  type        = string
}

variable "subnet_ids" {
  description = "ID du subnet IaaS pour chaque nom de subnet de grappes.yaml."
  type        = map(string)
}

variable "cle_ssh" {
  description = "Nom de la paire de cles injectee dans les VM."
  type        = string
}
