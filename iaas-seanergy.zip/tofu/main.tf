module "vm" {
  source   = "./modules/vm"
  for_each = local.vms

  hostname   = each.value.hostname
  ip         = each.value.ip
  image      = each.value.image
  flavor     = each.value.flavor
  cle_ssh    = var.cle_ssh
  network_id = var.network_id
  subnet_id  = var.subnet_ids[local.grappe.subnet]

  etiquettes = merge(local.etiquettes_communes, {
    role = each.value.role
  })
}
