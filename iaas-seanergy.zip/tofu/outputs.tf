# =============================================================================
# CONTRAT. Cet output est la seule interface entre OpenTofu et la doc.
# On n'y met AUCUNE metadonnee de CI (pipeline, date, commit) : sinon chaque
# execution changerait l'output et `tofu plan -detailed-exitcode` sortirait en 2,
# ce qui rendrait la detection de derive inutilisable.
#
# Toute evolution incompatible : incrementer `schema` et adapter tools/rendu.mjs.
# =============================================================================

output "inventaire" {
  description = "Etat declare de la grappe, consomme par tools/grappes.mjs render."

  value = {
    schema = 1

    grappe = {
      numero            = local.grappe.numero
      env               = local.grappe.env
      subnet            = local.grappe.subnet
      cidr              = "${local.conf.reseau.prefixe}.${local.octet_subnet}.0/24"
      version_composant = local.grappe.version_composant
    }

    vms = [
      for k, vm in local.vms : {
        role        = vm.role
        description = vm.description
        hostname    = vm.hostname
        ip          = vm.ip
        gabarit     = vm.gabarit
        vcpu        = vm.vcpu
        ram_go      = vm.ram_go
        disque_go   = vm.disque_go
        image       = vm.image
        id_iaas     = module.vm[k].id
      }
    ]
  }
}
